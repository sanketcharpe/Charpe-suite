/* =====================================================================
   CHARPE SUITE — OFFICIAL eCOURTS BACKEND                     Oct 2026
   ---------------------------------------------------------------------
   A separate Apps Script web app. It talks to the official eCourts
   site (services.ecourts.gov.in) on behalf of the Case Manager:

     • opens one eCourts session per case and hands back its CAPTCHA
     • when you type the CAPTCHA, searches the CNR and reads the case:
       next date, stage, status, judge, parties, hearing history, orders
     • downloads every order PDF into your Drive folder
       (Charpe Suite Data / eCourts Orders / <case> [CNR] / ...)
     • reads the "business on date" for each hearing
     • hands a saved PDF back to any of your devices — no CAPTCHA needed

   It never solves a CAPTCHA itself: you type every one.

   ADDED 21 OCT 2026 — no CAPTCHA needed for any of these
     • Supreme Court by case number (SLP(C), SLP(Crl), Civil / Criminal
       Appeal, W.P. …): one CAPTCHA to find the diary number, which the
       tool keeps — after that no CAPTCHA again   (actions scopen, scsearch)
     • Supreme Court of India by diary number (www.sci.gov.in): status,
       last / tentative next listing, listing history, every order and
       judgment PDF                                       (action sci)
     • CAT Mumbai Bench incl. Nagpur circuit (cis.cgat.gov.in/catlive):
       case details, proceedings, daily orders and final orders (action cat)
     • MAT Nagpur Bench: the Tribunal's own judgments list (action mat)
     • MAT Nagpur daily orders: the Order calendar (one combined PDF per
       sitting day) — the list of days and each day's PDF (matdays, matpdf);
       the tool itself finds your O.A. inside the day's PDF

   ADDED 20 OCT 2026
     • Bombay High Court (all benches) through hcservices.ecourts.gov.in —
       a CNR beginning HC goes there automatically
     • Search Courts: advocate / party / case-number search with one CAPTCHA
       (actions sopen, stypes, ssearch)
     • upload: an order PDF added by hand is kept in the case's Drive folder
     • mail: sends a letter or bill from YOUR Gmail, with the PDF attached.
       The first time after this update Google asks you to allow
       "Send email as you" — that is the one-time permission for this.

   SETUP — fill in the two values below, then Deploy → New deployment
   → Web app → Execute as: Me → Who has access: Anyone.
   ===================================================================== */

var SECRET    = 'PUT-YOUR-SYNC-PASSWORD-HERE';   // same password you use for Drive sync is fine
var FOLDER_ID = 'PUT-YOUR-DRIVE-FOLDER-ID-HERE'; // the "Charpe Suite Data" folder ID

var BASE          = 'https://services.ecourts.gov.in/ecourtindia_v6';
var ORDERS_FOLDER = 'eCourts Orders';
var SESSION_SECS  = 1500;                        // keep an eCourts session for 25 minutes

/* ------------------------------------------------------------------ */
function doGet() { return out({ ok: true, service: 'charpe-ecourts-official', version: 2 }); }

function doPost(e) {
  var b;
  try { b = JSON.parse(e.postData.contents); } catch (x) { return out({ ok: false, error: 'Bad request' }); }
  if (!b || b.token !== SECRET) return out({ ok: false, error: 'Wrong password for the eCourts backend' });
  try {
    switch (b.action) {
      case 'ping':    return out(ping());
      case 'start':   return out(startSessions(b.cnrs || []));
      case 'captcha': return out(newCaptcha(b.sid, b.cnr));
      case 'search':  return out(search(b));
      case 'order':   return out(getOrder(b));
      case 'biz':     return out(getBiz(b));
      case 'pdf':     return out(readPdf(b.fid));
      case 'sopen':   return out(sOpen(b));
      case 'stypes':  return out(sTypes(b));
      case 'ssearch': return out(sSearch(b));
      case 'upload':  return out(upload(b));
      case 'mail':    return out(sendMail(b));
      case 'sci':     return out(sciCase(b));
      case 'scopen':  return out(sciOpen(b));
      case 'scsearch':return out(sciSearch(b));
      case 'cat':     return out(catCase(b));
      case 'mat':     return out(matList(b));
      case 'matdays': return out(matDays(b));
      case 'matpdf':  return out(matPdf(b));
    }
    return out({ ok: false, error: 'Unknown action' });
  } catch (err) {
    return out({ ok: false, error: String(err && err.message || err) });
  }
}
function out(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }

/* ---------------- HTTP helpers ---------------- */
function rq(url, cookie, payload, sess) {
  var o = {
    url: url, muteHttpExceptions: true, followRedirects: true,
    method: payload === undefined ? 'get' : 'post',
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Safari/537.36',
      'Accept-Language': 'en-IN,en;q=0.9',
      'Referer': BASE + '/'
    }
  };
  /* page loads look like a browser; only the site's own ajax calls carry the ajax headers */
  o.headers.Accept = payload === undefined ? 'text/html,application/xhtml+xml,image/avif,image/webp,*/*;q=0.8' : 'application/json, text/javascript, */*; q=0.01';
  if (payload !== undefined) o.headers['X-Requested-With'] = 'XMLHttpRequest';
  if (cookie) o.headers.Cookie = cookie;
  if (payload !== undefined) {
    o.payload = payload;
    o.contentType = 'application/x-www-form-urlencoded; charset=UTF-8';
    if (sess && sess.hv) { o.headers.delimeter = sess.hv; if (sess.hk) o.headers[sess.hk] = sess.hv; }
  }
  return o;
}
function fetch1(o) {
  var u = o.url, p = {}; for (var k in o) if (k !== 'url') p[k] = o[k];
  for (var t = 0; ; t++) {
    try { return UrlFetchApp.fetch(u, p); }
    catch (e) { if (t >= 2) throw new Error('eCourts could not be reached just now (' + String(e.message || e).slice(0, 80) + '). Please try again.'); Utilities.sleep(900 * (t + 1)); }
  }
}
/* fetchAll with a gentle fallback: if Google's batch call trips, do them one by one with retries */
function fetchMany(list) {
  if (!list.length) return [];
  try { return UrlFetchApp.fetchAll(list); }
  catch (e) { Utilities.sleep(700); return list.map(function (o) { return fetch1(o); }); }
}

function cookieMerge(old, resp) {
  var h = resp.getAllHeaders(), sc = h['Set-Cookie'] || h['set-cookie'];
  if (!sc) return old || '';
  if (!Array.isArray(sc)) sc = [sc];
  var jar = {};
  String(old || '').split(/;\s*/).forEach(function (p) { var i = p.indexOf('='); if (i > 0) jar[p.slice(0, i)] = p.slice(i + 1); });
  sc.forEach(function (line) {
    var kv = String(line).split(';')[0], i = kv.indexOf('=');
    if (i > 0) jar[kv.slice(0, i).trim()] = kv.slice(i + 1).trim();
  });
  return Object.keys(jar).map(function (k) { return k + '=' + jar[k]; }).join('; ');
}
function enc(v) { return encodeURIComponent(v === undefined || v === null ? '' : String(v)); }
function imgData(r) {
  var b = r.getBlob();
  return 'data:' + (b.getContentType() || 'image/png') + ';base64,' + Utilities.base64Encode(b.getBytes());
}
function tokenFrom(html) {
  html = String(html || '');
  var tags = html.match(/<input[^>]*app_token[^>]*>/gi) || [];
  for (var i = 0; i < tags.length; i++) {
    var m = tags[i].match(/value\s*=\s*["']?([^"'\s>]+)/i);
    if (m && m[1].length >= 16) return m[1];
  }
  var j = html.match(/app_token["']?\s*[:=,]\s*["']([0-9A-Za-z]{16,})["']/) ||
          html.match(/["']([0-9a-f]{40,})["'][^<>]{0,60}app_token/i);
  return j ? j[1] : '';
}

/* ---------------- sessions ---------------- */
function sGet(sid) { var v = sid && CacheService.getScriptCache().get('s_' + sid); return v ? JSON.parse(v) : null; }
function sPut(sid, s) { CacheService.getScriptCache().put('s_' + sid, JSON.stringify(s), SESSION_SECS); }

/* The site's script file carries a header name/value pair that every ajax call must send. */
function headerPair(js) {
  var v = (js.match(/var\s+delimeter\s*=\s*["']([^"']+)["']/) || [])[1] || '';
  var k = (js.match(/["']?delimeter["']?\s*:\s*delimeter\s*,\s*["']?([A-Za-z0-9_\-]+)["']?\s*:\s*delimeter/) || [])[1] || '';
  return { hk: k, hv: v };
}
function compSrc(html) {
  var m = html.match(/src=["']([^"']*js\/components\.js[^"']*)["']/i);
  if (!m) return BASE + '/js/components.js';
  var u = unent(m[1]);
  return /^https?:/i.test(u) ? u : (u.charAt(0) === '/' ? 'https://services.ecourts.gov.in' + u : BASE + '/' + u);
}
function capSrc(divHtml) {
  var m = String(divHtml || '').match(/src=["']([^"']*securimage_show\.php[^"']*)["']/i);
  if (!m) return BASE + '/vendor/securimage/securimage_show.php?' + Math.random();
  var u = unent(m[1]).trim();
  if (/^https?:/i.test(u)) return u;
  if (u.charAt(0) === '/') return 'https://services.ecourts.gov.in' + u;
  return BASE + '/' + u.replace(/^\.\//, '');
}
function parseJson(r) { try { return JSON.parse(r.getContentText().replace(/^﻿/, '')); } catch (e) { return {}; } }

/* Open n fresh sessions: home page → script file (header pair) → getCaptcha (token + picture) → picture. */
function openSessions(n) {
  var homes = fetchMany(range(n).map(function () { return rq(BASE + '/'); }));
  var ss = homes.map(function (r) {
    var html = r.getContentText();
    return { cookie: cookieMerge('', r), token: tokenFrom(html), code: r.getResponseCode(), comp: compSrc(html) };
  });
  var hp = pairFor(ss[0]);
  ss.forEach(function (s) { s.hk = hp.hk; s.hv = hp.hv; });
  function askCaptcha(list) {
    var res = fetchMany(list.map(function (s) {
      return rq(BASE + '/?p=casestatus/getCaptcha', s.cookie, '&ajax_req=true&app_token=' + enc(s.token), s);
    }));
    res.forEach(function (r, i) {
      var s = list[i], j = parseJson(r);
      s.cookie = cookieMerge(s.cookie, r);
      if (j.app_token) s.token = j.app_token;
      s.capErr = j.errormsg ? strip(j.errormsg).slice(0, 140) : (j.div_captcha ? '' : 'no picture in the answer');
      s.img = capSrc(j.div_captcha);
    });
  }
  askCaptcha(ss);
  /* a brand-new session may only receive its token on the first call: ask once more with it */
  var again = ss.filter(function (s) { return s.capErr && s.token; });
  if (again.length) askCaptcha(again);
  var imgs = fetchMany(ss.map(function (s) { return rq(s.img, s.cookie); }));
  imgs.forEach(function (r, i) { ss[i].cookie = cookieMerge(ss[i].cookie, r); ss[i].pic = r; });
  return ss;
}
function pairFor(s) {
  var c = CacheService.getScriptCache(), key = 'hp_' + Utilities.base64EncodeWebSafe(s.comp).slice(-40), v = c.get(key);
  if (v) return JSON.parse(v);
  var r = fetch1(rq(s.comp, s.cookie)), hp = headerPair(r.getContentText());
  if (hp.hv) c.put(key, JSON.stringify(hp), 600);
  return hp;
}
function range(n) { var a = []; for (var i = 0; i < n; i++) a.push(i); return a; }

function ping() {
  var s = openSessions(1)[0];
  var ok = !!(s.token && s.hv && !s.capErr && s.pic && s.pic.getResponseCode() === 200 && /image/i.test(s.pic.getBlob().getContentType() || ''));
  return { ok: true, folder: rootFolder().getName(), site: s.code, reachable: ok,
           headerFound: !!s.hv, tokenFound: !!s.token, captchaError: s.capErr || '',
           picture: s.pic ? s.pic.getResponseCode() + ' ' + (s.pic.getBlob().getContentType() || '') : 'none' };
}

/* One fresh eCourts session (with its own CAPTCHA) per case. */
function startSessions(cnrs) {
  var rows = [], hcIdx = [], dc = [];
  cnrs.forEach(function (c, i) { if (/^HC/i.test(String(c))) hcIdx.push(i); else dc.push(c); });
  if (hcIdx.length) {
    var dcRows = dc.length ? startDistrict(dc).rows : [], out = [], d = 0;
    cnrs.forEach(function (c) { out.push(/^HC/i.test(String(c)) ? hcStartRow(c) : dcRows[d++]); });
    return { ok: true, rows: out };
  }
  return startDistrict(cnrs);
}
function startDistrict(cnrs) {
  var rows = [];
  for (var i = 0; i < cnrs.length; i += 4) {
    var part = cnrs.slice(i, i + 4), ss;
    try { ss = openSessions(part.length); }
    catch (e) { part.forEach(function (c) { rows.push({ cnr: c, sid: '', err: String(e.message || e) }); }); continue; }
    ss.forEach(function (s, k) {
      var sid = Utilities.getUuid(), row = { cnr: part[k], sid: sid }, pic = s.pic;
      delete s.pic;
      if (!s.token || s.capErr || !pic || pic.getResponseCode() !== 200)
        row.err = 'The eCourts site did not give a CAPTCHA' + (s.capErr ? ' (' + s.capErr + ')' : '') + '. Try again in a minute.';
      else { sPut(sid, s); row.img = imgData(pic); }
      rows.push(row);
    });
  }
  return { ok: true, rows: rows };
}

/* A new CAPTCHA picture — on the same session if it is still alive, else a fresh one. */
function newCaptcha(sid, cnr) {
  var s = sGet(sid);
  if (s && s.hc) return { ok: true, sid: sid, img: hcPicture(sid, s) };
  if (!s) { var st = startSessions([cnr]).rows[0]; return { ok: true, sid: st.sid, img: st.img, err: st.err }; }
  return { ok: true, sid: sid, img: freshPicture(sid, s) };
}
function freshPicture(sid, s) {
  var src = BASE + '/vendor/securimage/securimage_show.php?' + Math.random();
  try { var j = ajax(s, 'casestatus/getCaptcha', ''); if (j.div_captcha) src = capSrc(j.div_captcha); } catch (e) {}
  var r = fetch1(rq(src, s.cookie));
  s.cookie = cookieMerge(s.cookie, r); sPut(sid, s);
  return imgData(r);
}

/* POST to one of the site's ajax pages, keeping the rolling app_token. */
function ajax(s, page, data) {
  var r = fetch1(rq(BASE + '/?p=' + page, s.cookie, data + '&ajax_req=true&app_token=' + enc(s.token), s));
  s.cookie = cookieMerge(s.cookie, r);
  var t = r.getContentText().replace(/^﻿/, ''), j;
  try { j = JSON.parse(t); }
  catch (e) {
    var parts = t.split('#####');
    if (parts[1]) s.token = parts[1].trim();
    else { var m = t.match(/"app_token":"([^"]+)"/); if (m) s.token = m[1]; }
    var why = strip(parts[0] || t).slice(0, 180);
    var err = new Error(why || ('eCourts did not answer properly (HTTP ' + r.getResponseCode() + ')'));
    err.soft = true; throw err;
  }
  if (j && j.app_token) s.token = j.app_token;
  return j || {};
}

/* ---------------- search by CNR ---------------- */
function search(b) {
  var s = sGet(b.sid);
  if (!s) return { ok: true, expired: true };
  if (s.hc) return hcSearch(b, s);
  var cnr = String(b.cnr || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  var j;
  try { j = ajax(s, 'cnr_status/searchByCNR/', 'cino=' + enc(cnr) + '&fcaptcha_code=' + enc(String(b.captcha || '').trim())); }
  catch (e) { sPut(b.sid, s); if (e.soft) return retry(b.sid, s, e.message); throw e; }
  sPut(b.sid, s);
  var html = j.casetype_list || '';
  if (String(j.status) === '0' || (!html && (j.errormsg || j.div_captcha))) {
    return retry(b.sid, s, strip(j.errormsg || '') || 'Wrong CAPTCHA');
  }
  var dm = html.match(/id=["']sess_dist_code["'][^>]*value=["']([^"']*)/i);
  if (dm) { s.dist = dm[1]; sPut(b.sid, s); }
  var d = parseCase(html);
  if (!d.found) {
    saveDebug(cnr, html || JSON.stringify(j));
    var txt = strip(html).slice(0, 200);
    return { ok: true, notFound: true, msg: txt || 'eCourts returned no details for this CNR.' };
  }
  if (!d.next && !d.hist.length && !d.orders.length) saveDebug(cnr, html);
  return { ok: true, data: d };
}
function retry(sid, s, msg) {
  if (s.hc) return { ok: true, bad: true, msg: msg || 'Wrong CAPTCHA', img: hcPicture(sid, s) };
  return { ok: true, bad: true, msg: msg || 'Wrong CAPTCHA', img: freshPicture(sid, s) };
}
function saveDebug(cnr, text) {
  try {
    var f = rootFolder(), name = '_ecourts_last_response.html', it = f.getFilesByName(name);
    var body = '<!-- ' + cnr + ' ' + new Date().toISOString() + ' -->\n' + text;
    if (it.hasNext()) it.next().setContent(body); else f.createFile(name, body, MimeType.HTML);
  } catch (e) {}
}

/* ---------------- parsing the case page ---------------- */
var MON = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
function pad(n) { n = String(n); return n.length < 2 ? '0' + n : n; }
function isoDate(s) {
  s = String(s || '');
  var m = s.match(/(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})/);
  if (m) return m[3] + '-' + pad(m[2]) + '-' + pad(m[1]);
  m = s.match(/(\d{1,2})(?:st|nd|rd|th)?\s+([A-Za-z]{3,})\.?,?\s+(\d{4})/);
  if (m) { var mi = MON.indexOf(m[2].slice(0, 3).toLowerCase()); if (mi >= 0) return m[3] + '-' + pad(mi + 1) + '-' + pad(m[1]); }
  m = s.match(/(\d{4})-(\d{2})-(\d{2})/);
  if (m) return m[0];
  return '';
}
function unent(h) {
  return String(h || '').replace(/&nbsp;/gi, ' ').replace(/&amp;/gi, '&').replace(/&lt;/gi, '<').replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"').replace(/&#0?39;|&apos;/gi, "'").replace(/&#(\d+);/g, function (_, n) { return String.fromCharCode(+n); });
}
function strip(h) {
  return unent(String(h || '').replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<br\s*\/?>/gi, '\n').replace(/<\/(p|div|tr|li|h\d)>/gi, '\n').replace(/<[^>]+>/g, ' '))
    .replace(/[ \t\r\f\v]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{2,}/g, '\n').trim();
}
function norm(s) { return String(s || '').toLowerCase().replace(/[^a-z]/g, ''); }

function tables(html) {
  var list = [], re = /<table([^>]*)>([\s\S]*?)<\/table>/gi, m;
  while ((m = re.exec(html))) {
    var cls = ((m[1].match(/class\s*=\s*["']([^"']*)/i) || [])[1] || '') + ' ' + ((m[1].match(/id\s*=\s*["']([^"']*)/i) || [])[1] || '');
    var rows = [], rr = /<tr[^>]*>([\s\S]*?)<\/tr>/gi, r;
    while ((r = rr.exec(m[2]))) {
      var cells = [], cr = /<t([dh])([^>]*)>([\s\S]*?)<\/t[dh]>/gi, c;
      while ((c = cr.exec(r[1]))) cells.push({ h: c[1].toLowerCase() === 'h', raw: unent(c[2] + ' ' + c[3]), t: strip(c[3]) });
      if (cells.length) rows.push(cells);
    }
    var before = html.slice(Math.max(0, m.index - 500), m.index), hd = '', hm, hre = /<(h[1-6]|strong|b|label|span)[^>]*>([\s\S]*?)<\/\1>/gi;
    while ((hm = hre.exec(before))) { var tx = strip(hm[2]); if (tx) hd = tx; }
    list.push({ cls: cls.toLowerCase(), rows: rows, heading: hd });
  }
  return list;
}
function jsArgs(raw, fn) {
  var m = String(raw || '').match(new RegExp(fn + '\\s*\\(([^)]*)\\)', 'i'));
  if (!m) return null;
  var args = [], re = /'([^']*)'|"([^"]*)"|([^,\s][^,]*)/g, a;
  while ((a = re.exec(m[1]))) args.push((a[1] !== undefined ? a[1] : a[2] !== undefined ? a[2] : a[3]).trim());
  return args;
}
function headerIndex(row, words) {
  for (var i = 0; i < row.length; i++) { var t = norm(row[i].t); for (var w = 0; w < words.length; w++) if (t.indexOf(words[w]) >= 0) return i; }
  return -1;
}

function parseCase(html) {
  var d = { found: false, hist: [], orders: [] }, kv = {};
  var tbs = tables(html);
  tbs.forEach(function (tb) {
    var first = tb.rows[0] || [], ht = norm(first.map(function (c) { return c.t; }).join('|'));
    /* hearing history */
    if (/history_table/.test(tb.cls) || (ht.indexOf('businessondate') >= 0 && ht.indexOf('hearingdate') >= 0)) {
      var iJ = headerIndex(first, ['judge']), iB = headerIndex(first, ['businessondate']),
          iH = headerIndex(first, ['hearingdate']), iP = headerIndex(first, ['purpose']);
      if (iB < 0) { iJ = 0; iB = 1; iH = 2; iP = 3; }
      tb.rows.slice(1).forEach(function (r) {
        if (r.length < 3) return;
        var bd = isoDate(r[iB] && r[iB].t), hd = iH >= 0 ? isoDate(r[iH] && r[iH].t) : '';
        if (!bd && !hd) return;
        d.hist.push({ bd: bd, d: hd, j: iJ >= 0 && r[iJ] ? r[iJ].t : '', p: iP >= 0 && r[iP] ? r[iP].t : '',
                      a: jsArgs(r[iB] && r[iB].raw, 'viewBusiness') });
      });
      d.found = true; return;
    }
    /* orders */
    if (/order_table/.test(tb.cls) || ht.indexOf('orderdate') >= 0) {
      var iN = headerIndex(first, ['ordernumber', 'orderno']), iD = headerIndex(first, ['orderdate']), iT = headerIndex(first, ['orderdetail', 'details']);
      var title = /final/i.test(tb.heading) ? 'Final Order' : (/interim/i.test(tb.heading) ? 'Order' : 'Order');
      tb.rows.forEach(function (r, ri) {
        var raw = r.map(function (c) { return c.raw; }).join(' ');
        var a = jsArgs(raw, 'displayPdf');
        if (!a || a.length < 4) return;
        var od = iD >= 0 && r[iD] ? isoDate(r[iD].t) : isoDate(r.map(function (c) { return c.t; }).join(' '));
        var no = iN >= 0 && r[iN] ? r[iN].t : '';
        var det = iT >= 0 && r[iT] ? r[iT].t : '';
        var t2 = /judg/i.test(det) ? 'Judgment' : (/final/i.test(det) ? 'Final Order' : title);
        d.orders.push({ key: okey(a), no: no, d: od, title: t2, a: a });
      });
      d.found = true; return;
    }
    /* label / value tables */
    tb.rows.forEach(function (r) {
      for (var i = 0; i + 1 < r.length; i += 2) {
        var k = norm(r[i].t); if (k && kv[k] === undefined) kv[k] = r[i + 1].t;
      }
    });
    if (tb.cls.indexOf('petitioner') >= 0) d.pet = strip(tb.rows.map(function (r) { return r.map(function (c) { return c.t; }).join(' '); }).join('\n'));
    if (tb.cls.indexOf('respondent') >= 0) d.res = strip(tb.rows.map(function (r) { return r.map(function (c) { return c.t; }).join(' '); }).join('\n'));
  });
  /* some pages put the parties in <span> blocks rather than tables */
  if (!d.pet) { var pm = html.match(/class=["'][^"']*Petitioner_Advocate_table[^"']*["'][^>]*>([\s\S]*?)<\/(?:table|span|div)>/i); if (pm) d.pet = strip(pm[1]); }
  if (!d.res) { var rm = html.match(/class=["'][^"']*Respondent_Advocate_table[^"']*["'][^>]*>([\s\S]*?)<\/(?:table|span|div)>/i); if (rm) d.res = strip(rm[1]); }

  function g() { for (var i = 0; i < arguments.length; i++) { var v = kv[arguments[i]]; if (v) return v; } return ''; }
  d.ctype    = g('casetype');
  d.filing   = g('filingnumber');
  d.reg      = g('registrationnumber');
  d.cnr      = g('cnrnumber');
  d.first    = isoDate(g('firsthearingdate'));
  d.next     = isoDate(g('nexthearingdate', 'nextdate'));
  d.decision = isoDate(g('decisiondate', 'dateofdecision'));
  d.stage    = g('casestage', 'stageofcase');
  d.status   = g('casestatus', 'status');
  d.disposal = g('natureofdisposal');
  d.judge    = g('courtnumberandjudge', 'courtnoandjudge');
  d.disposed = !!(d.decision || d.disposal || /dispos/i.test(d.status + ' ' + d.stage));
  if (d.ctype || d.reg || d.cnr || d.next || d.stage || d.status) d.found = true;
  /* the purpose shown against the next date, if the history has it */
  if (d.next) d.hist.forEach(function (h) { if (h.d === d.next && h.p) d.purpose = h.p; });
  if (!d.purpose && d.hist.length) { var last = d.hist[d.hist.length - 1]; if (last.d === d.next) d.purpose = last.p; }
  d.pet = (d.pet || '').slice(0, 600); d.res = (d.res || '').slice(0, 600);
  return d;
}
function okey(a) {
  var raw = Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, (a[2] || '') + '|' + (a[3] || ''));
  return raw.map(function (b) { return ('0' + ((b + 256) % 256).toString(16)).slice(-2); }).join('').slice(0, 14);
}

/* ---------------- one order → Drive ---------------- */
function getOrder(b) {
  var a = b.a || [];
  if (a[0] === 'SCI' || a[0] === 'CAT' || a[0] === 'MAT') return directOrder(b, a);
  var s = sGet(b.sid);
  if (!s) return { ok: true, expired: true };
  var folder = caseFolder(b.cnr, b.label);
  var name = fileName(b);
  var ex = folder.getFilesByName(name);
  if (ex.hasNext()) { var f0 = ex.next(); return done(f0, b.want); }
  if (a[0] === 'HC') return hcOrder(b, s, a[1], folder, name);

  var j = ajax(s, 'home/display_pdf',
    'normal_v=' + enc(a[0]) + '&case_val=' + enc(a[1]) + '&court_code=' + enc(a[2]) + '&filename=' + enc(a[3]) + '&appFlag=' + enc(a[4] || ''));
  sPut(b.sid, s);
  if (!j.order) return { ok: true, missing: true, msg: strip(j.errormsg || '') || 'eCourts has no PDF for this order' };
  var path = String(j.order).replace(/^\.?\//, '');
  var url = /^https?:/i.test(path) ? path : BASE + '/' + path;
  var r = fetch1(rq(url, s.cookie));
  s.cookie = cookieMerge(s.cookie, r); sPut(b.sid, s);
  var bytes = r.getContent();
  if (r.getResponseCode() !== 200 || bytes.length < 5 || String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]) !== '%PDF')
    return { ok: true, missing: true, msg: 'The PDF could not be downloaded (HTTP ' + r.getResponseCode() + ')' };
  var file = folder.createFile(Utilities.newBlob(bytes, 'application/pdf', name));
  return done(file, b.want, bytes);
}
function done(file, want, bytes) {
  var o = { ok: true, fid: file.getId(), name: file.getName(), folder: file.getParents().next().getName(), size: file.getSize() };
  if (want && o.size < 6 * 1024 * 1024) o.b64 = Utilities.base64Encode(bytes || file.getBlob().getBytes());
  return o;
}
function clean(s) { return String(s || '').replace(/[\\\/:*?"<>|#%]+/g, ' ').replace(/\s+/g, ' ').trim(); }
function fileName(b) {
  return clean((b.d || 'undated') + ' ' + (b.title || 'Order') + (b.no ? ' No ' + b.no : '')).slice(0, 120) + '.pdf';
}

/* ---------------- business on a hearing date ---------------- */
function getBiz(b) {
  var s = sGet(b.sid);
  if (!s) return { ok: true, expired: true };
  if (s.hc) return { ok: true, text: '' };
  var a = b.a || [];
  // viewBusiness(court_code,dist_code,n_dt,case_number,state_code,businessStatus,todays_date1,court_no,national_court_code,caseStatusSearchType,srno)
  var data = 'court_code=' + enc(a[0]) + '&state_code=' + enc(a[4]) + '&dist_code=' + enc(s.dist || a[1]) +
    '&nextdate1=' + enc(a[2]) + '&case_number1=' + enc(a[3]) + '&state_code=' + enc(a[4]) +
    '&disposal_flag=' + enc(a[5]) + '&businessDate=' + enc(a[6]) + '&national_court_code=' + enc(a[8]) +
    '&court_no=' + enc(a[7]) + '&search_by=' + enc(a[9] || 'cnr') + '&srno=' + enc(a[10]);
  var j = ajax(s, 'home/viewBusiness', data);
  sPut(b.sid, s);
  var t = strip(j.data_list || '');
  var m = t.match(/Business\s*:?\s*([\s\S]*?)(?:\n\s*Next Purpose|\n\s*Next Hearing Date|$)/i);
  var txt = (m && m[1] ? m[1] : t).replace(/\s+/g, ' ').trim();
  return { ok: true, text: txt.slice(0, 700) };
}

/* ---------------- Drive ---------------- */
function rootFolder() { return DriveApp.getFolderById(FOLDER_ID); }
function ordersFolder() {
  var p = PropertiesService.getScriptProperties(), id = p.getProperty('ordersFolder');
  if (id) { try { var f = DriveApp.getFolderById(id); if (!f.isTrashed()) return f; } catch (e) {} }
  var root = rootFolder(), it = root.getFoldersByName(ORDERS_FOLDER);
  var fo = it.hasNext() ? it.next() : root.createFolder(ORDERS_FOLDER);
  p.setProperty('ordersFolder', fo.getId());
  return fo;
}
function caseFolder(cnr, label) {
  cnr = String(cnr || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  var p = PropertiesService.getScriptProperties(), key = 'cf_' + cnr, id = p.getProperty(key);
  if (id) { try { var f = DriveApp.getFolderById(id); if (!f.isTrashed()) return f; } catch (e) {} }
  var of = ordersFolder(), it = of.searchFolders("title contains '" + cnr + "' and trashed = false");
  var fo = it.hasNext() ? it.next() : of.createFolder(clean((label || 'Case').slice(0, 80) + ' [' + cnr + ']'));
  p.setProperty(key, fo.getId());
  return fo;
}
function readPdf(fid) {
  var file = DriveApp.getFileById(fid), ok = false, ofId = ordersFolder().getId();
  var ps = file.getParents();
  while (ps.hasNext() && !ok) { var pp = ps.next().getParents(); while (pp.hasNext()) if (pp.next().getId() === ofId) ok = true; }
  if (!ok) throw new Error('That file is not one of the saved eCourts orders.');
  return { ok: true, name: file.getName(), folder: file.getParents().next().getName(), b64: Utilities.base64Encode(file.getBlob().getBytes()) };
}

/* Run this once from the editor (select "authorise" and press Run) so Google asks for permission. */
function authorise() { rootFolder().getName(); UrlFetchApp.fetch(BASE + '/', { muteHttpExceptions: true }); }

/* Diagnostic: choose "testSite" next to Debug and press Run; the result shows in the Execution log. */
function testSite() { Logger.log(JSON.stringify(ping(), null, 2)); }

/* =====================================================================
   ADDED 20 OCT 2026
   ===================================================================== */

/* ---------------- Bombay High Court (hcservices.ecourts.gov.in) ----------------
   The High Court site is older than the district one. Its page names are kept
   here in one place so they can be corrected quickly if the site changes:
   every answer it gives that cannot be read is saved in your Drive folder as
   _hc_last_response.html. */
var HC = {
  BASE:    'https://hcservices.ecourts.gov.in/hcservices',
  HOME:    '/main.php',
  CAPTCHA: '/securimage/securimage_show.php?',
  QRY:     '/cases_qry/index_qry.php?action_code=',
  HISTORY: '/cases_qry/o_civil_case_history.php',
  STATE:   '1',                                          // Maharashtra on the HC site
  BENCHES: { principal: /principal|bombay|mumbai/i, aurangabad: /aurangabad/i, nagpur: /nagpur/i, goa: /goa/i }
};
function hcRq(path, s, payload) {
  var o = rq(HC.BASE + path, s && s.cookie, payload);
  o.headers.Referer = HC.BASE + HC.HOME;
  return o;
}
function hcOpen() {
  var r = fetch1(hcRq(HC.HOME, null)), s = { hc: true, cookie: cookieMerge('', r), code: r.getResponseCode() };
  var p = fetch1(hcRq(HC.CAPTCHA + Math.random(), s));
  s.cookie = cookieMerge(s.cookie, p);
  return { s: s, pic: p };
}
function hcStartRow(cnr) {
  try {
    var o = hcOpen(), sid = Utilities.getUuid();
    if (o.pic.getResponseCode() !== 200) return { cnr: cnr, sid: '', err: 'The High Court site did not give a CAPTCHA (HTTP ' + o.pic.getResponseCode() + '). Try again in a minute.' };
    sPut(sid, o.s);
    return { cnr: cnr, sid: sid, img: imgData(o.pic) };
  } catch (e) { return { cnr: cnr, sid: '', err: String(e.message || e) }; }
}
function hcPicture(sid, s) {
  var p = fetch1(hcRq(HC.CAPTCHA + Math.random(), s));
  s.cookie = cookieMerge(s.cookie, p); sPut(sid, s);
  return imgData(p);
}
function hcPost(s, path, data) {
  var r = fetch1(hcRq(path, s, data));
  s.cookie = cookieMerge(s.cookie, r);
  return r.getContentText().replace(/^﻿/, '');
}
function hcDebug(tag, text) {
  try {
    var f = rootFolder(), name = '_hc_last_response.html', it = f.getFilesByName(name);
    var body = '<!-- ' + tag + ' ' + new Date().toISOString() + ' -->\n' + text;
    if (it.hasNext()) it.next().setContent(body); else f.createFile(name, body, MimeType.HTML);
  } catch (e) {}
}
function hcWrong(t) { return /invalid captcha|captcha.*(wrong|invalid|mismatch)|enter.*captcha/i.test(String(t).slice(0, 600)); }

/* HC CNR: HCBM + bench(2) + number(6) + year(4) */
function hcSearch(b, s) {
  var cnr = String(b.cnr || '').toUpperCase().replace(/[^A-Z0-9]/g, ''), cap = String(b.captcha || '').trim();
  var t = hcPost(s, HC.HISTORY, 'cino=' + enc(cnr) + '&appFlag=web&captcha=' + enc(cap) + '&fcaptcha_code=' + enc(cap) +
    '&state_code=' + HC.STATE + '&court_code=&court_complex_code=&case_no=');
  sPut(b.sid, s);
  if (hcWrong(t)) return retry(b.sid, s, 'Wrong CAPTCHA');
  var j = null; try { j = JSON.parse(t); } catch (e) {}
  var html = j ? (j.data || j.html || j.con || j.casetype_list || t) : t;
  if (Array.isArray(html)) html = html.join('');
  var d = parseCase(String(html));
  hcOrders(String(html), d);
  d.hist.forEach(function (h) { h.a = null; });            /* the HC site has no per-date business text */
  if (!d.found) { hcDebug('cnr ' + cnr, t); return { ok: true, notFound: true, msg: (strip(String(html)).slice(0, 160) || 'The High Court site returned nothing readable.') + ' (saved as _hc_last_response.html in your Drive folder)' }; }
  if (!d.next && !d.hist.length) hcDebug('cnr ' + cnr, t);
  return { ok: true, data: d };
}
/* order links on the HC page point straight at the PDF */
function hcOrders(html, d) {
  var re = /<a[^>]+href=["']([^"']*display_pdf[^"']*)["'][^>]*>([\s\S]*?)<\/a>/gi, m, seen = {};
  while ((m = re.exec(html))) {
    var url = unent(m[1]); if (seen[url]) continue; seen[url] = 1;
    var row = html.slice(Math.max(0, m.index - 400), m.index + 50);
    var dd = (row.match(/(\d{1,2}[-\/.]\d{1,2}[-\/.]\d{4})(?![\s\S]*\d{1,2}[-\/.]\d{1,2}[-\/.]\d{4})/) || [])[1];
    var key = Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, url).map(function (x) { return ('0' + ((x + 256) % 256).toString(16)).slice(-2); }).join('').slice(0, 14);
    if (d.orders.some(function (o) { return o.key === key; })) continue;
    d.orders.push({ key: key, no: '', d: isoDate(dd || ''), title: /judg/i.test(strip(m[2])) ? 'Judgment' : 'Order', a: ['HC', url] });
    d.found = true;
  }
}
function hcOrder(b, s, url, folder, name) {
  var u = /^https?:/i.test(url) ? url : HC.BASE + '/' + String(url).replace(/^\.?\//, '');
  var r = fetch1(rq(u, s.cookie)); s.cookie = cookieMerge(s.cookie, r); sPut(b.sid, s);
  var bytes = r.getContent();
  if (r.getResponseCode() !== 200 || bytes.length < 5 || String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]) !== '%PDF')
    return { ok: true, missing: true, msg: 'The High Court PDF could not be downloaded (HTTP ' + r.getResponseCode() + ')' };
  return done(folder.createFile(Utilities.newBlob(bytes, 'application/pdf', name)), b.want, bytes);
}

/* ---------------- SEARCH COURTS ---------------- */
function opts(html) {
  var out = [], re = /<option[^>]*value=["']([^"']*)["'][^>]*>([\s\S]*?)<\/option>/gi, m;
  while ((m = re.exec(String(html || '')))) { var t = strip(m[2]); if (m[1] && m[1] !== '0' && t && !/^select/i.test(t)) out.push({ v: m[1], t: t }); }
  return out;
}
function tilde(t) {   /* "1~Principal Seat#2~Bench at Aurangabad#" → list */
  return String(t || '').split('#').map(function (p) { var a = p.split('~'); return a.length > 1 && a[0] && a[0] !== '0' ? { v: a[0].trim(), t: strip(a[1]) } : null; }).filter(Boolean);
}
function firstStr(j, re) {
  var hit = '';
  (function walk(x) { if (hit) return; if (typeof x === 'string') { if (re.test(x)) hit = x; } else if (x && typeof x === 'object') Object.keys(x).forEach(function (k) { walk(x[k]); }); })(j);
  return hit;
}
function sOpen(b) {
  if (b.via === 'hc') {
    var o = hcOpen(), s = o.s, sid = Utilities.getUuid(), lists = {}, note = '';
    try {
      var benches = tilde(hcPost(s, HC.QRY + 'fillHCBench', 'state_code=' + HC.STATE + '&appFlag=web'));
      var re = HC.BENCHES[b.bench] || HC.BENCHES.nagpur, bc = benches.filter(function (x) { return re.test(x.t); })[0];
      lists.benches = benches;
      if (bc) { s.bench = bc.v; var types = tilde(hcPost(s, HC.QRY + 'fillCaseType', 'state_code=' + HC.STATE + '&court_code=' + enc(bc.v) + '&appFlag=web')); lists.types = types; }
      else { note = 'Could not read the list of benches from the High Court site.'; hcDebug('benches', JSON.stringify(benches)); }
    } catch (e) { note = 'High Court lists did not load: ' + e.message; }
    if (o.pic.getResponseCode() !== 200) throw new Error('The High Court site did not give a CAPTCHA.');
    o.pic = fetch1(hcRq(HC.CAPTCHA + Math.random(), s)); s.cookie = cookieMerge(s.cookie, o.pic);
    sPut(sid, s);
    return { ok: true, sid: sid, img: imgData(o.pic), lists: lists, types: lists.types || [], note: note };
  }
  /* district courts: Maharashtra → Nagpur → court complexes */
  var ss = openSessions(1), s2 = ss[0], sid2 = Utilities.getUuid(), pic = s2.pic; delete s2.pic;
  if (!s2.token || s2.capErr) throw new Error('eCourts did not give a CAPTCHA' + (s2.capErr ? ' (' + s2.capErr + ')' : '') + '.');
  var L = { est: [] };
  try {
    s2.state = '1';
    var dj = ajax(s2, 'casestatus/fillDistrict', 'state_code=1');
    var dists = opts(firstStr(dj, /<option/i)), dn = dists.filter(function (x) { return new RegExp(b.district || 'Nagpur', 'i').test(x.t); })[0];
    if (dn) {
      s2.dist = dn.v;
      var cj = ajax(s2, 'casestatus/fillcomplex', 'state_code=1&dist_code=' + enc(dn.v));
      L.est = opts(firstStr(cj, /<option/i));
    }
  } catch (e) { L.err = String(e.message || e); }
  sPut(sid2, s2);
  return { ok: true, sid: sid2, img: imgData(pic), lists: L, note: L.est.length ? '' : 'Could not read the list of courts for Nagpur' + (L.err ? ': ' + L.err : '') };
}
function splitEst(v) { var p = String(v || '').split('@'); return { complex: p[0] || '', est: p[1] || '' }; }
function sTypes(b) {
  var s = sGet(b.sid); if (!s) return { ok: true, expired: true };
  if (s.hc) return { ok: true, types: tilde(hcPost(s, HC.QRY + 'fillCaseType', 'state_code=' + HC.STATE + '&court_code=' + enc(s.bench) + '&appFlag=web')) };
  var e = splitEst(b.est);
  var j = ajax(s, 'casestatus/fillCaseType', 'state_code=1&dist_code=' + enc(s.dist) + '&court_complex_code=' + enc(e.complex) + '&est_code=' + enc(e.est) + '&search_type=c_no');
  sPut(b.sid, s);
  return { ok: true, types: opts(firstStr(j, /<option/i)) };
}
function sSearch(b) {
  var s = sGet(b.sid); if (!s) return { ok: true, expired: true };
  var cap = String(b.captcha || '').trim(), st = b.status || 'Pending';
  if (s.hc) {
    var type = b.mode === 'adv' ? 'CSAdvName' : b.mode === 'party' ? 'CSpartyName' : 'CScaseNumber';
    var t = hcPost(s, HC.QRY + 'showRecords', 'court_code=' + enc(s.bench) + '&state_code=' + HC.STATE + '&court_complex_code=' + enc(s.bench) +
      '&caseStatusSearchType=' + type + '&captcha=' + enc(cap) + '&case_type=' + enc(b.type) + '&case_no=' + enc(b.no) + '&rgyear=' + enc(b.year) +
      '&caseNoType=new&displayOldCaseNo=NO&adv_name=' + enc(b.q) + '&advocate_name=' + enc(b.q) + '&party_name=' + enc(b.q) + '&petres_name=' + enc(b.q) +
      '&f=' + enc(st) + '&status=' + enc(st) + '&appFlag=web');
    sPut(b.sid, s);
    if (hcWrong(t)) return { ok: true, bad: true, sid: b.sid, img: hcPicture(b.sid, s) };
    var rows = hcRows(t);
    if (!rows.length) hcDebug('search ' + type, t);
    return { ok: true, sid: b.sid, rows: rows.slice(0, 200), more: rows.length > 200, img: hcPicture(b.sid, s),
             msg: rows.length ? '' : (strip(t).slice(0, 140) || 'Nothing found') + ' — saved as _hc_last_response.html' };
  }
  var e = pickEst(s, b), base = '&state_code=1&dist_code=' + enc(s.dist) + '&court_complex_code=' + enc(e.complex) + '&est_code=' + enc(e.est);
  var j, page, data;
  if (b.mode === 'adv') { page = 'casestatus/submitAdvName'; data = 'radAdvt=1&advocate_name=' + enc(b.q) + '&adv_bar_state=&adv_bar_code=&adv_bar_year=&case_status=' + enc(st) + '&caselist_date=&adv_captcha_code=' + enc(cap) + base; }
  else if (b.mode === 'party') { page = 'casestatus/submitPartyName'; data = 'petres_name=' + enc(b.q) + '&rgyearP=' + enc(b.year) + '&case_status=' + enc(st) + '&fcaptcha_code=' + enc(cap) + base; }
  else { page = 'casestatus/submitCaseNo'; data = 'case_type=' + enc(b.type) + '&search_case_no=' + enc(b.no) + '&rgyear=' + enc(b.year) + '&case_captcha_code=' + enc(cap) + base; }
  try { j = ajax(s, page, data); }
  catch (er) { sPut(b.sid, s); if (er.soft && /captcha/i.test(er.message)) return { ok: true, bad: true, sid: b.sid, img: freshPicture(b.sid, s) }; throw er; }
  sPut(b.sid, s);
  var html = firstStr(j, /viewHistory|<table|<tr/i);
  if (String(j.status) === '0' || (!html && /captcha/i.test(JSON.stringify(j).slice(0, 400)))) return { ok: true, bad: true, sid: b.sid, img: freshPicture(b.sid, s) };
  var rows2 = dcRows(html);
  if (!rows2.length) saveDebug('search ' + page, JSON.stringify(j));
  return { ok: true, sid: b.sid, rows: rows2.slice(0, 200), more: rows2.length > 200, img: freshPicture(b.sid, s),
           msg: rows2.length ? '' : (strip(j.errormsg || html || '').slice(0, 140) || 'Nothing found') };
}
/* one establishment, or all of them that match the quick pick */
function pickEst(s, b) {
  if (b.est) return splitEst(b.est);
  return { complex: '', est: '' };
}
function dcRows(html) {
  var out = [], seen = {}, court = '';
  tables(String(html || '')).forEach(function (tb) {
    tb.rows.forEach(function (r) {
      var raw = r.map(function (c) { return c.raw; }).join(' '), txt = r.map(function (c) { return c.t; });
      if (r.length === 1 && !/viewHistory/.test(raw)) { court = txt[0]; return; }
      var cn = (raw.match(/\b([A-Z]{4}\d{12})\b/) || [])[1]; if (!cn || seen[cn]) return; seen[cn] = 1;
      var par = txt.filter(function (t) { return /\b(vs\.?|versus|v\/s)\b/i.test(t); })[0] || '';
      var pp = par.split(/\s+(?:vs\.?|versus|v\/s)\s+/i);
      var no = txt.filter(function (t) { return /\/\s*\d{4}/.test(t) && t !== par; })[0] || '';
      out.push({ cnr: cn, no: no.replace(/\s+/g, ' '), pet: (pp[0] || '').trim(), res: (pp[1] || '').trim(), court: court });
    });
  });
  return out;
}
function hcRows(t) {
  var out = [], seen = {};
  function add(o) {
    var cn = String(o.cino || o.cnr || '').toUpperCase(); if (!/^HC[A-Z]{2}\d{12}$/.test(cn) || seen[cn]) return; seen[cn] = 1;
    out.push({ cnr: cn, no: strip([o.type_name || o.case_type || '', (o.case_no2 || o.reg_no || o.case_no || '') + (o.reg_year || o.case_year ? '/' + (o.reg_year || o.case_year) : '')].join(' ')).trim(),
               pet: strip(o.pet_name || o.petparty_name || ''), res: strip(o.res_name || o.resparty_name || ''), adv: strip(o.adv_name || o.pet_adv || ''), court: 'Bombay High Court', disposed: /dispos/i.test(o.status || o.disp_nature || '') });
  }
  (function walk(x) {
    if (typeof x === 'string') { if (/^\s*[\[{]/.test(x)) { try { walk(JSON.parse(x)); } catch (e) {} } return; }
    if (Array.isArray(x)) { x.forEach(walk); return; }
    if (x && typeof x === 'object') { if (x.cino || x.cnr) add(x); Object.keys(x).forEach(function (k) { walk(x[k]); }); }
  })((function () { try { return JSON.parse(t); } catch (e) { return t; } })());
  if (!out.length) dcRows(t).forEach(function (r) { if (/^HC/.test(r.cnr) && !seen[r.cnr]) { seen[r.cnr] = 1; r.court = 'Bombay High Court'; out.push(r); } });
  if (!out.length) { var re = /\b(HC[A-Z]{2}\d{12})\b/g, m; while ((m = re.exec(t))) if (!seen[m[1]]) { seen[m[1]] = 1; out.push({ cnr: m[1], no: '', pet: '', res: '', court: 'Bombay High Court' }); } }
  return out;
}

/* ---------------- an order PDF added by hand ---------------- */
function upload(b) {
  if (!b.b64) throw new Error('No file was sent.');
  var folder = caseFolder(b.cnr || 'MANUAL', b.label);
  var name = clean(b.name || 'Order').replace(/\.pdf$/i, '') + '.pdf';
  var file = folder.createFile(Utilities.newBlob(Utilities.base64Decode(b.b64), 'application/pdf', name));
  return { ok: true, fid: file.getId(), name: file.getName(), folder: folder.getName() };
}

/* ---------------- email from your own Gmail ----------------
   to / cc: comma-separated addresses. attachments: [{name, b64, type}] */
function sendMail(b) {
  var to = String(b.to || '').trim();
  if (!/@/.test(to)) throw new Error('Give at least one email address.');
  var opt = { name: b.fromName || 'Adv. Sanket R. Charpe', attachments: [] };
  if (b.cc) opt.cc = String(b.cc);
  if (b.bcc) opt.bcc = String(b.bcc);
  if (b.replyTo) opt.replyTo = String(b.replyTo);
  (b.attachments || []).forEach(function (a) {
    if (a && a.b64) opt.attachments.push(Utilities.newBlob(Utilities.base64Decode(a.b64), a.type || 'application/pdf', a.name || 'attachment.pdf'));
  });
  var size = opt.attachments.reduce(function (n, x) { return n + x.getBytes().length; }, 0);
  if (size > 24 * 1024 * 1024) throw new Error('The attachments are larger than Gmail allows (25 MB).');
  GmailApp.sendEmail(to, String(b.subject || ''), String(b.body || ''), opt);
  return { ok: true, sent: true, to: to, at: new Date().toISOString(), quota: MailApp.getRemainingDailyQuota() };
}

/* Run once from the editor after pasting this update (choose authoriseAll and press Run),
   so Google asks for every permission in one go, including sending email. */
function authoriseAll() {
  rootFolder().getName();
  UrlFetchApp.fetch(BASE + '/', { muteHttpExceptions: true });
  UrlFetchApp.fetch(HC.BASE + HC.HOME, { muteHttpExceptions: true });
  GmailApp.getAliases();
  Logger.log('Permissions are in place. Mail left today: ' + MailApp.getRemainingDailyQuota());
}

/* =====================================================================
   ADDED 21 OCT 2026 — SUPREME COURT, CAT, MAT (no CAPTCHA on any of them)
   Anything that cannot be read is saved in your Drive folder as
   _sci_last_response.html / _cat_last_response.html / _mat_last_response.html
   ===================================================================== */
function plainRq(url, cookie, referer) {
  return { url: url, muteHttpExceptions: true, followRedirects: true, method: 'get', validateHttpsCertificates: true,
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Safari/537.36',
               'Accept-Language': 'en-IN,en;q=0.9', 'Referer': referer || url, 'Cookie': cookie || '' } };
}
function debugFile(name, tag, text) {
  try {
    var f = rootFolder(), it = f.getFilesByName(name), body = '<!-- ' + tag + ' ' + new Date().toISOString() + ' -->\n' + text;
    if (it.hasNext()) it.next().setContent(body); else f.createFile(name, body, MimeType.HTML);
  } catch (e) {}
}
function isPdf(bytes) { return bytes && bytes.length > 4 && String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]) === '%PDF'; }
function md5k(t) {
  return Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, String(t)).map(function (x) { return ('0' + ((x + 256) % 256).toString(16)).slice(-2); }).join('').slice(0, 14);
}

/* ---------------- SUPREME COURT ---------------- */
var SCI = { BASE: 'https://www.sci.gov.in', AJAX: 'https://www.sci.gov.in/wp-admin/admin-ajax.php' };
/* the Supreme Court's firewall turns away bare requests: look like the site's own page asking (cookies from a first visit, the same headers) */
var SCIS = { cookie: '', at: 0 };
function sciHeaders(o) {
  o.headers.Accept = 'application/json, text/javascript, */*; q=0.01';
  o.headers['X-Requested-With'] = 'XMLHttpRequest';
  o.headers['Sec-Fetch-Site'] = 'same-origin'; o.headers['Sec-Fetch-Mode'] = 'cors'; o.headers['Sec-Fetch-Dest'] = 'empty';
  o.headers['sec-ch-ua'] = '"Chromium";v="129", "Google Chrome";v="129", "Not=A?Brand";v="8"'; o.headers['sec-ch-ua-mobile'] = '?0'; o.headers['sec-ch-ua-platform'] = '"Windows"';
  return o;
}
function sciWarm(force) {
  if (!force && SCIS.cookie && Date.now() - SCIS.at < 600000) return;
  var o = plainRq(SCI.BASE + '/case-status-diary-no/', '', SCI.BASE + '/');
  o.headers.Accept = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8';
  o.headers['Upgrade-Insecure-Requests'] = '1'; o.headers['Sec-Fetch-Site'] = 'same-origin'; o.headers['Sec-Fetch-Mode'] = 'navigate'; o.headers['Sec-Fetch-Dest'] = 'document';
  var r = fetch1(o); SCIS.cookie = cookieMerge('', r); SCIS.at = Date.now();
}
function sciGet(dn, dy, tab) {
  var u = SCI.AJAX + '?diary_no=' + enc(dn) + '&diary_year=' + enc(dy) + '&tab_name=' + enc(tab || '') +
          '&action=get_case_details&es_ajax_request=1&language=en';
  sciWarm(false);
  var r = fetch1(sciHeaders(plainRq(u, SCIS.cookie, SCI.BASE + '/case-status-diary-no/')));
  if (r.getResponseCode() === 403) { Utilities.sleep(800); sciWarm(true); r = fetch1(sciHeaders(plainRq(u, SCIS.cookie, SCI.BASE + '/case-status-diary-no/'))); }
  var t = r.getContentText(), j = null;
  try { j = JSON.parse(t.replace(/^﻿/, '')); } catch (e) {}
  if (!j) {
    debugFile('_sci_last_response.html', 'diary ' + dn + '/' + dy + ' ' + tab, t);
    if (r.getResponseCode() === 403) throw new Error('The Supreme Court site turned away the request from the Google servers (its firewall, HTTP 403).');
    throw new Error('The Supreme Court site did not answer properly (HTTP ' + r.getResponseCode() + '). Saved as _sci_last_response.html.');
  }
  if (!j.success) { var m = ''; try { m = JSON.parse(j.data).message; } catch (e) { m = strip(String(j.data || '')); } return { none: m || 'Nothing found' }; }
  return { html: String(j.data || '') };
}
/* diary number from what the case card holds: "38471/2025", or the CNR SCIN01 038471 2025 */
function sciDiary(b) {
  var dn = String(b.diary || '').replace(/\s/g, ''), m = dn.match(/^(\d{1,7})\/(\d{4})$/);
  if (m) return { no: String(+m[1]), yr: m[2] };
  var c = String(b.cnr || '').toUpperCase().replace(/[^A-Z0-9]/g, ''), n = c.match(/^SCIN\d{2}(\d{6})(\d{4})$/);
  if (n) return { no: String(+n[1]), yr: n[2] };
  if (b.no && b.year) return { no: String(+b.no), yr: String(b.year) };
  return null;
}
function sciCase(b) {
  var di = sciDiary(b);
  if (!di) throw new Error('Give the Supreme Court diary number as 12345/2025 (or the CNR beginning SCIN).');
  var main = sciGet(di.no, di.yr, '');
  if (main.none) return { ok: true, notFound: true, msg: 'Supreme Court: ' + main.none };
  var html = main.html, kv = {};
  tables(html).forEach(function (tb) { tb.rows.forEach(function (r) { if (r.length >= 2) { var k = norm(r[0].t); if (k && kv[k] === undefined) kv[k] = r[1].t; } }); });
  function g(re) { for (var k in kv) if (re.test(k)) return kv[k]; return ''; }
  var title = strip((html.match(/<h4[^>]*>([\s\S]*?)<\/h4>/i) || [])[1] || '');
  var pp = title.split(/\s+vs\.?\s+/i);
  var status = g(/^statusstage/), last = g(/^presentlastlistedon/), tent = g(/^tentatively/);
  var d = { found: true, court: 'Supreme Court of India', hist: [], orders: [] };
  d.cnr = (g(/^cnrnumber/).match(/SCIN\d{12}/) || [''])[0];
  d.diary = di.no + '/' + di.yr;
  d.reg = g(/^casenumber/).replace(/\s+/g, ' ').slice(0, 200);
  d.ctype = (d.reg.match(/^([A-Za-z.() ]+?)\s*No/) || [])[1] || '';
  d.pet = (g(/^petitioners?$/) || pp[0] || '').replace(/^\d+\s+/, '').slice(0, 600);
  d.res = (g(/^respondents?$/) || pp[1] || '').replace(/^\d+\s+/, '').slice(0, 600);
  d.status = status.slice(0, 300);
  d.stage = (status.match(/\(([^()]*(?:\([^()]*\))?[^()]*)\)/) || [])[1] || '';
  d.judge = ((last.match(/\[([^\]]+)\]/) || [])[1] || '').replace(/([A-Z.])and /g, '$1 and ').trim();
  d.lastListed = isoDate(last);
  d.next = isoDate(tent);
  if (d.next) d.purpose = 'Tentatively listed (computer generated)';
  var fixed = status.match(/List On \(Date\)\s*\((\d{2}-\d{2}-\d{4})\)/i);
  if (fixed && isoDate(fixed[1]) >= (d.next || '')) { d.next = isoDate(fixed[1]); d.purpose = 'List on (date) fixed by the Court'; }
  d.disposed = /^\s*disposed/i.test(status);
  if (d.disposed) { d.decision = isoDate((status.match(/Disposal Date:\s*([\d-]+)/i) || [])[1] || ''); d.disposal = g(/^disptype/); d.next = ''; }
  /* listing history */
  try {
    var ld = sciGet(di.no, di.yr, 'listing_dates');
    if (ld.html) tables(ld.html).forEach(function (tb) {
      var head = tb.rows[0] || [], iD = headerIndex(head, ['cldate']), iS = headerIndex(head, ['stage']), iP = headerIndex(head, ['purpose']),
          iJ = headerIndex(head, ['judges']), iR = headerIndex(head, ['remarks']);
      if (iD < 0) return;
      tb.rows.slice(1).forEach(function (r) {
        var dd = isoDate(r[iD] && r[iD].t); if (!dd) return;
        d.hist.push({ d: dd, bd: dd, p: [iS >= 0 && r[iS] ? r[iS].t : '', iR >= 0 && r[iR] ? r[iR].t : ''].filter(Boolean).join(' — '), j: iJ >= 0 && r[iJ] ? r[iJ].t : '', a: null });
      });
    });
    d.hist.sort(function (x, y) { return x.d < y.d ? -1 : 1; });
  } catch (e) {}
  /* orders and judgments */
  var jo = sciGet(di.no, di.yr, 'judgement_orders'), seen = {};
  if (jo.html) {
    var re = /<a[^>]+href=["']([^"']+\.pdf)["'][^>]*>([\s\S]*?)<\/a>([\s\S]*?)(?=<a|<\/td>)/gi, m;
    while ((m = re.exec(jo.html))) {
      var url = unent(m[1]); if (seen[url]) continue; seen[url] = 1;
      var lab = strip(m[3]).replace(/^\W+|\W+$/g, ''), od = isoDate(strip(m[2])) || isoDate((url.match(/_(\d{2}-[A-Za-z]{3}-\d{4})\.pdf$/) || [])[1] || '');
      var kind = /judg/i.test(url + ' ' + lab) ? 'Judgment' : 'Order';
      d.orders.push({ key: md5k(url), no: '', d: od, title: kind + (/ROP/i.test(lab) ? ' (ROP)' : ''), a: ['SCI', url] });
    }
  }
  return { ok: true, data: d };
}

/* Supreme Court by case number: the site asks a CAPTCHA (a small sum) for this search only.
   sciOpen  → reads the search form (its hidden fields) and returns the CAPTCHA picture
   sciSearch→ sends the form with your answer; returns the matching diary number(s) */
function sciForm(s) {
  var r = fetch1(plainRq(SCI.BASE + '/case-status-case-no/', s.cookie, SCI.BASE + '/'));
  s.cookie = cookieMerge(s.cookie, r);
  var h = r.getContentText(), f = (h.match(/<form[^>]*id=["']sciapi-services-case-status-case-no["'][\s\S]*?<\/form>/i) || [])[0] || '';
  if (!f) { debugFile('_sci_last_response.html', 'case-no form', h); throw new Error('The Supreme Court search form could not be read (saved as _sci_last_response.html).'); }
  var fields = {}, re = /<input[^>]*>/gi, m;
  while ((m = re.exec(f))) {
    var t = m[0], n = (t.match(/name=["']([^"']+)["']/i) || [])[1], v = (t.match(/value=["']([^"']*)["']/i) || [])[1], ty = (t.match(/type=["']([^"']+)["']/i) || [])[1] || 'text';
    if (n && /hidden|submit/i.test(ty) && v !== undefined) fields[n] = unent(v);
  }
  s.fields = fields;
  var img = (f.match(/<img[^>]*id=["']siwp_captcha_image_0["'][^>]*src=["']([^"']+)["']/i) || f.match(/src=["']([^"']*_siwp_captcha[^"']*)["']/i) || [])[1];
  img = img ? unent(img) : SCI.BASE + '/?_siwp_captcha&id=' + (fields.scid || '');
  if (!/^https?:/.test(img)) img = SCI.BASE + (img.charAt(0) === '/' ? '' : '/') + img;
  var p = fetch1(plainRq(img, s.cookie, SCI.BASE + '/case-status-case-no/'));
  s.cookie = cookieMerge(s.cookie, p);
  return imgData(p);
}
function sciOpen(b) {
  var s = { sci: true, cookie: '' }, sid = Utilities.getUuid(), img = sciForm(s);
  sPut(sid, s);
  return { ok: true, sid: sid, img: img };
}
function sciSearch(b) {
  var s = sGet(b.sid); if (!s || !s.sci) return { ok: true, expired: true };
  var data = Object.keys(s.fields || {}).map(function (k) { return enc(k) + '=' + enc(s.fields[k]); });
  data.push('case_type=' + enc(b.type), 'case_no=' + enc(b.no), 'year=' + enc(b.year), 'siwp_captcha_value=' + enc(String(b.captcha || '').trim()),
            'action=get_case_status_case_no', 'language=en');
  var o = plainRq(SCI.AJAX, s.cookie, SCI.BASE + '/case-status-case-no/');
  o.method = 'post'; o.payload = data.join('&'); o.contentType = 'application/x-www-form-urlencoded; charset=UTF-8';
  o.headers['X-Requested-With'] = 'XMLHttpRequest'; o.headers.Accept = 'application/json, text/javascript, */*; q=0.01';
  var r = fetch1(o); s.cookie = cookieMerge(s.cookie, r);
  var t = r.getContentText(), j = null; try { j = JSON.parse(t.replace(/^﻿/, '')); } catch (e) {}
  if (!j) { debugFile('_sci_last_response.html', 'case-no search', t); throw new Error('The Supreme Court site did not answer properly (saved as _sci_last_response.html).'); }
  if (!j.success) {
    var msg = ''; try { msg = JSON.parse(j.data).message; } catch (e) { msg = strip(String(j.data || '')); }
    var img = sciForm(s); sPut(b.sid, s);                     /* a fresh form and picture for the next try */
    return { ok: true, bad: /captcha/i.test(msg), msg: msg || 'Nothing found', img: img };
  }
  var html = String(j.data && j.data.resultsHtml !== undefined ? j.data.resultsHtml : j.data || ''), rows = [], seen = {};
  html.split(/<tr\b/i).forEach(function (part) {
    var dn = (part.match(/data-diary-no=["'](\d+)["']/i) || [])[1], dy = (part.match(/data-diary-year=["'](\d+)["']/i) || [])[1];
    if (!dn || !dy || seen[dn + '/' + dy]) return; seen[dn + '/' + dy] = 1;
    var cells = [], cr = /<td[^>]*>([\s\S]*?)<\/td>/gi, c; while ((c = cr.exec(part))) cells.push(strip(c[1]).replace(/\s+/g, ' '));
    rows.push({ diary: dn + '/' + dy, text: cells.filter(Boolean).join(' · ').slice(0, 400) });
  });
  if (!rows.length) {   /* some answers are the case page itself */
    var m = html.match(/Diary No\.?\s*-?\s*(\d+)\s*\/\s*(\d{4})/i); if (m) rows.push({ diary: m[1] + '/' + m[2], text: strip(html).slice(0, 300) });
  }
  if (!rows.length) debugFile('_sci_last_response.html', 'case-no results', html);
  sPut(b.sid, s);
  return { ok: true, rows: rows, msg: rows.length ? '' : 'No case found with that number (saved as _sci_last_response.html).' };
}

/* ---------------- CAT (cis.cgat.gov.in/catlive) ----------------
   Same route as your CAT Order Compiler: partyDetail.php → additional_mis.php → PDF */
var CAT = { BASE: 'https://cis.cgat.gov.in/catlive/', BENCH: '210', BENCH_NAME: 'mumbai',
  TYPES: { OA: '1', TA: '2', MA: '3', CP: '4', PT: '5', RA: '6', CCP: '7', OAOBJ: '8' } };
function b64e(t) { return Utilities.base64Encode(t); }
function b64d(t) { t = String(t).replace(/%3D/gi, '='); while (t.length % 4) t += '='; return Utilities.newBlob(Utilities.base64Decode(t)).getDataAsString(); }
function catGet(path, s, ref) {
  var r = fetch1(plainRq(/^https?:/.test(path) ? path : CAT.BASE + path, s.cookie, ref ? (/^https?:/.test(ref) ? ref : CAT.BASE + ref) : CAT.BASE + 'case_status.php'));
  s.cookie = cookieMerge(s.cookie, r);
  return r;
}
function catSession() {
  var s = { cookie: '' }, home = 'home1.php?no=' + b64e(CAT.BENCH);
  catGet('index.php', s, 'index.php'); catGet(home, s, 'index.php'); catGet('case_status.php', s, home);
  return s;
}
function catType(t) { var k = String(t || 'OA').toUpperCase().replace(/[^A-Z]/g, '').replace(/^CRCP$/, 'CCP'); return CAT.TYPES[k] ? k : 'OA'; }
function catCase(b) {
  var tk = catType(b.type), no = String(b.no || '').replace(/\D/g, ''), yr = String(b.year || '').replace(/\D/g, '');
  if (!no || yr.length !== 4) throw new Error('Give the CAT case type, number and year (e.g. O.A. 297/2026).');
  var s = catSession();
  var html = catGet('partyDetail.php?caseNo=' + no + '&benchCode1=' + CAT.BENCH + '&caseType=' + CAT.TYPES[tk] + '&year=' + yr + '&id=casetypewise', s).getContentText();
  var hits = [];
  tables(html).forEach(function (tb) { tb.rows.forEach(function (r) {
    var raw = r.map(function (c) { return c.raw; }).join(' '), m = raw.match(/popsurety_detailreport\(\s*'([^']+)'/);
    if (m) hits.push({ token: m[1], diary: r[0] && r[0].t, place: r[1] && r[1].t, no: r[3] && r[3].t, filed: r[4] && r[4].t, pet: r[5] && r[5].t, res: r[6] && r[6].t });
  }); });
  if (!hits.length) { debugFile('_cat_last_response.html', tk + ' ' + no + '/' + yr, html); return { ok: true, notFound: true, msg: 'CAT Mumbai shows no ' + tk + ' ' + no + '/' + yr + '. (Saved as _cat_last_response.html.)' }; }
  var h = hits[0];
  if (hits.length > 1 && b.party) { var pw = norm(b.party); hits.forEach(function (x) { if (pw && (norm(x.pet).indexOf(pw.slice(0, 6)) >= 0)) h = x; }); }
  var caseId = b64d(h.token).split('/')[0], detail = 'Misdetailreport123.php?no=' + h.token, dhtml = '';
  var ordersUrl = 'additional_mis.php?diary_no=' + b64e(caseId + '/' + CAT.BENCH_NAME + '/D');
  try {
    dhtml = catGet(detail, s).getContentText();
    var mm = dhtml.match(/\.?\/?(additional_mis\.php\?diary_no=[A-Za-z0-9+\/=%]+)/); if (mm) ordersUrl = mm[1];
  } catch (e) {}
  var ohtml = catGet(ordersUrl, s, detail).getContentText();
  var d = { found: true, court: 'CAT Mumbai Bench', hist: [], orders: [], diary: h.diary, reg: h.no || (tk + ' ' + no + '/' + yr), pet: h.pet, res: h.res, filing: h.filed, place: h.place };
  /* label / value pairs from the detail page */
  var kv = {};
  tables(dhtml).forEach(function (tb) { tb.rows.forEach(function (r) { for (var i = 0; i + 1 < r.length; i += 2) { var k = norm(r[i].t); if (k && kv[k] === undefined && r[i + 1].t) kv[k] = r[i + 1].t; } }); });
  function g(re) { for (var k in kv) if (re.test(k)) return kv[k]; return ''; }
  d.status = g(/casestatus|^status/); d.stage = g(/stage|purpose/);
  d.next = isoDate(g(/nextdate|nexthearing|nextlist|dateofnext/));
  d.decision = isoDate(g(/disposaldate|dateofdisposal|decisiondate|dateofdecision/));
  d.disposal = g(/natureofdisposal|disposalnature|disposedof/);
  d.disposed = !!(d.decision || /dispos/i.test(d.status));
  /* the three sections of additional_mis.php */
  var section = '', rows = ohtml.replace(/<!--[\s\S]*?-->/g, '').split(/<tr[\s>]/i);
  rows.forEach(function (row) {
    var th = (row.match(/<th[^>]*>([\s\S]*?)<\/th>/i) || [])[1];
    if (th) { var T = strip(th).toUpperCase(); section = /FINAL ORDER/.test(T) ? 'final' : /ORDER DETAILS/.test(T) ? 'daily' : /PROCEEDING/.test(T) ? 'proc' : section; return; }
    var live = row.replace(/<!--[\s\S]*?-->/g, ''), cells = [], cr = /<td[^>]*>([\s\S]*?)<\/td>/gi, c;
    while ((c = cr.exec(live))) cells.push(strip(c[1]));
    if (!cells.length) return;
    var dd = isoDate(cells[0]);
    if (section === 'proc') {
      var all = cells.map(isoDate).filter(Boolean);
      if (all.length) d.hist.push({ d: all[all.length - 1] > all[0] ? all[all.length - 1] : all[0], bd: all[0], p: cells.slice(1).filter(function (x) { return x && !isoDate(x); }).join(' — ').slice(0, 300), j: '', a: null });
      return;
    }
    if (section !== 'final' && section !== 'daily' || !dd) return;
    var a = live.match(/href=["']([^"']*(?:qrpdfview[^"']*|\.pdf))["']/i); if (!a) return;
    var url = unent(a[1]); url = /^https?:/.test(url) ? url : CAT.BASE + url.replace(/^\.?\//, '');
    d.orders.push({ key: md5k(url), no: '', d: dd, title: section === 'final' ? 'Final Order / Judgment' : 'Daily Order', a: ['CAT', url] });
  });
  /* next date from the proceedings when the detail page has none */
  if (!d.next) { var t = Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd'); d.hist.forEach(function (x) { if (x.d > t && (!d.next || x.d > d.next)) d.next = x.d; }); }
  if (!d.orders.length && !d.hist.length) debugFile('_cat_last_response.html', 'orders ' + tk + ' ' + no + '/' + yr, ohtml + '\n<!-- DETAIL -->\n' + dhtml);
  if (hits.length > 1) d.note = hits.length + ' CAT cases share this number (different places/years) — the first was used: ' + h.place;
  return { ok: true, data: d };
}
/* CAT PDFs: the viewer page only wraps the real file; go to the source, as your compiler does */
function catPdf(url) {
  var s = catSession(), tok = (url.match(/file=([A-Za-z0-9+\/=%]+)/) || [])[1], jud = /_jud/.test(url), tries = [];
  if (tok) { tries = jud ? ['internal/secure-pdf-jud.php?file=', 'secure-pdf-serve.php?file='] : ['secure-pdf-serve.php?file=', 'internal/secure-pdf-jud.php?file=']; tries = tries.map(function (e) { return CAT.BASE + e + tok; }); }
  for (var i = 0; i < tries.length; i++) { var r = catGet(tries[i], s, url), by = r.getContent(); if (isPdf(by)) return by; }
  try {
    var page = catGet(url, s).getContentText(), m = page.match(/pdfUrl\s*=\s*['"]([^'"]+)['"]/);
    if (m) { var u = /^https?:/.test(m[1]) ? m[1] : CAT.BASE + m[1].replace(/^\.?\//, ''), r2 = catGet(u, s, url).getContent(); if (isPdf(r2)) return r2; }
  } catch (e) {}
  if (tok) { var rel = b64d(tok); [CAT.BASE + rel, CAT.BASE + 'pdf/' + rel].forEach(function (u) { if (!tries.ok) { try { var r3 = catGet(u, s, url).getContent(); if (isPdf(r3)) tries.ok = r3; } catch (e) {} } }); if (tries.ok) return tries.ok; }
  if (/\.pdf($|\?)/i.test(url)) { var r4 = catGet(url, s).getContent(); if (isPdf(r4)) return r4; }
  return null;
}

/* ---------------- MAT NAGPUR ---------------- */
var MAT = { FEED: 'https://uatmat.mahaitgov.in/api/final-judgments/2', PAGE: 'https://mat.maharashtra.gov.in/nagpur',
  FILES: 'https://uatmat.mahaitgov.in/storage/finalord/' };
function matList(b) {
  var out = [], why = [];
  try {
    var r = fetch1(plainRq(MAT.FEED, '', MAT.PAGE)), t = r.getContentText(), j = JSON.parse(t.replace(/^﻿/, ''));
    (Array.isArray(j) ? j : (j.data || [])).forEach(function (x) {
      out.push({ c: String(x.oa_num || ''), ap: String(x.applicant_name || ''), di: x.districts && x.districts.name || '', adv: String(x.applicants_adv || ''),
        rs: String(x.respondents_details || '').slice(0, 160), sj: x.bsubjects && x.bsubjects.board_subject || '', dt: String(x.decision_date || ''),
        dc: String(x.decision || '').slice(0, 160), u: x.file_name ? MAT.FILES + String(x.file_name) : '' });
    });
  } catch (e) { why.push('feed: ' + (e.message || e)); }
  if (b.old) {   /* the older judgments are written into the page itself */
    try {
      var h = fetch1(plainRq(MAT.PAGE)).getContentText();
      tables(h).forEach(function (tb) { tb.rows.forEach(function (r) {
        if (r.length < 10) return;
        var u = (r.map(function (c) { return c.raw; }).join(' ').match(/href=["']([^"']+)["']/i) || [])[1] || '';
        if (u && !/^https?:/.test(u)) u = 'https://mat.maharashtra.gov.in/' + u.replace(/^[.\/]+/, '');
        out.push({ c: r[0].t, ap: r[1].t, di: r[2].t, adv: r[3].t, rs: r[4].t.slice(0, 160), sj: r[6].t, dt: r[7].t, dc: r[8].t.slice(0, 160), u: unent(u) });
      }); });
    } catch (e) { why.push('page: ' + (e.message || e)); }
  }
  if (!out.length) debugFile('_mat_last_response.html', 'mat', why.join('\n'));
  return { ok: true, rows: out, note: why.join('; ') };
}

/* MAT Nagpur daily orders: Download → Order → Nagpur <year> is a calendar fed by this list;
   each sitting day has one PDF ("Dias matters dated …") with every order passed that day. */
MAT.DAYS = 'https://uatmat.mahaitgov.in/api/day-status/2';
MAT.ORDERS = 'https://uatmat.mahaitgov.in/storage/orders/';
function matDays(b) {
  var r = fetch1(plainRq(MAT.DAYS, '', 'https://mat.maharashtra.gov.in/nagpur_calendar_2026.html')), t = r.getContentText(), j = null;
  try { j = JSON.parse(t.replace(/^\uFEFF/, '')); } catch (e) {}
  if (!Array.isArray(j)) { debugFile('_mat_last_response.html', 'day-status', t); throw new Error('The MAT Order calendar could not be read (saved as _mat_last_response.html).'); }
  var days = [], hol = [];
  j.forEach(function (x) {
    var d = String(x.order_date || '').slice(0, 10);
    if (x.order_file_name) days.push({ d: d, f: String(x.order_file_name) });
    else if (x.is_holiday) hol.push({ d: d, t: String(x.holiday_title || '') });
  });
  return { ok: true, days: days, holidays: hol };
}
function matPdf(b) {
  var f = String(b.f || ''); if (!f || /[\\\/]|\.\./.test(f)) throw new Error('Bad file name');
  var r = fetch1(plainRq(MAT.ORDERS + encodeURIComponent(f), '', 'https://mat.maharashtra.gov.in/'));
  var bytes = r.getContent();
  if (!isPdf(bytes)) return { ok: true, missing: true, msg: 'The MAT order file for that day could not be downloaded (HTTP ' + r.getResponseCode() + ').' };
  return { ok: true, b64: Utilities.base64Encode(bytes), size: bytes.length };
}

/* ---------------- one PDF from SC / CAT / MAT → Drive ---------------- */
function directOrder(b, a) {
  var folder = caseFolder(b.cnr, b.label), name = fileName(b), ex = folder.getFilesByName(name);
  if (ex.hasNext()) return done(ex.next(), b.want);
  var bytes = null;
  if (a[0] === 'CAT') bytes = catPdf(a[1]);
  else { var r = fetch1(plainRq(encodeURI(decodeURI(a[1])), '', a[0] === 'SCI' ? SCI.BASE + '/' : MAT.PAGE)); bytes = r.getContent(); }
  if (!isPdf(bytes)) return { ok: true, missing: true, msg: 'The PDF could not be downloaded from the ' + (a[0] === 'SCI' ? 'Supreme Court' : a[0]) + ' site just now.' };
  return done(folder.createFile(Utilities.newBlob(bytes, 'application/pdf', name)), b.want, bytes);
}

/* Diagnostic: choose testCourts next to Debug and press Run — the Execution log shows what each site returned. */
function testCourts() {
  try { var s1 = sciCase({ diary: '38471/2025' }); Logger.log('Supreme Court: ' + (s1.data ? s1.data.pet + ' v ' + s1.data.res + ', ' + s1.data.orders.length + ' orders' : s1.msg)); } catch (e) { Logger.log('Supreme Court failed: ' + e.message); }
  try { var c1 = catCase({ type: 'OA', no: '297', year: '2026' }); Logger.log('CAT: ' + (c1.data ? c1.data.pet + ' v ' + c1.data.res + ', ' + c1.data.orders.length + ' orders, next ' + c1.data.next : c1.msg)); } catch (e) { Logger.log('CAT failed: ' + e.message); }
  try { var m1 = matList({}); Logger.log('MAT Nagpur: ' + m1.rows.length + ' judgments in the feed ' + (m1.note || '')); } catch (e) { Logger.log('MAT failed: ' + e.message); }
}
